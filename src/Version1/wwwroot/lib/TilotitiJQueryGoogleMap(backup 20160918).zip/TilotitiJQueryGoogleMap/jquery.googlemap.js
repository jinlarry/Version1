$(function() {
    var globalinfo; var globalcolor;
	$.fn.googleMap = function(params) {
		params = $.extend( {
			zoom : 10,
			coords : [48.895651, 2.290569],
			type : "ROADMAP",
			debug : false,
			langage : "english",
			overviewMapControl: false,
			streetViewControl: false,
			scrollwheel: false,
			mapTypeControl: false
		}, params);

		switch(params.type) {
			case 'ROADMAP':
			case 'SATELLITE':
			case 'HYBRID':
			case 'TERRAIN':
				params.type = google.maps.MapTypeId[params.type];
				break;
			default:
				params.type = google.maps.MapTypeId.ROADMAP;
				break;
		}

		this.each(function() {

			var map = new google.maps.Map(this, {
				zoom: params.zoom,
				center: new google.maps.LatLng(params.coords[0], params.coords[1]),
				mapTypeId: params.type,
				scrollwheel: params.scrollwheel,
				streetViewControl: params.streetViewControl,
				overviewMapControl: params.overviewMapControl,
				mapTypeControl: params.mapTypeControl

			});

			$(this).data('googleMap', map);
			$(this).data('googleLang', params.langage);
			$(this).data('googleDebug', params.debug);
			$(this).data('googleMarker', new Array());
			$(this).data('googleBound', new google.maps.LatLngBounds());		 
		});

		return this;
	}
	
	$.fn.addMarker = function (params) {
	     
		params = $.extend( {
			coords : false,
			address : false,
			url : false,
			id : false,
			icon : false,
			draggable : false,
			title : "",
			text : "",
			success : function() {}
		}, params);

		this.each(function() {
			$this = $(this);

			if(!$this.data('googleMap')) {
				if($this.data('googleDebug'))
					console.error("jQuery googleMap : Unable to add a marker where there is no map !");
					
				return false;
			}

			if(!params.coords && !params.address) {
				if($this.data('googleDebug'))
					console.error("jQuery googleMap : Unable to add a marker if you don't tell us where !");
					
				return false;
			}
			 
			if(params.address && typeof params.address == "string") {
				var geocodeAsync = function($that) {
					var geocoder = new google.maps.Geocoder();
					geocoder.geocode({
						address : params.address,
						bounds : $that.data('googleBound'),
						language : $that.data('googleLang')
					}, function(results, status) {
					    
						if (status == google.maps.GeocoderStatus.OK) {
							$that.data('googleBound').extend(results[0].geometry.location);

							if(params.icon) {
								var marker = new google.maps.Marker({
									map: $this.data('googleMap'),
									position: results[0].geometry.location,
									title: params.title,
									icon: params.icon,
									draggable: params.draggable
								});
							} else {
								var marker = new google.maps.Marker({
									map: $that.data('googleMap'),
									position: results[0].geometry.location,
									title: params.title,
									draggable: params.draggable
								});
							}

							if (params.draggable) {
							    
								google.maps.event.addListener(marker, 'dragend', function() {
									var location = marker.getPosition();
								
									var coords = {};

									coords.lat = location.lat();
									coords.lon = location.lng();

									params.success(coords, $this);
								});
							}
							
							if(params.title != "" && params.text != "" && !params.url) {
								var infowindow = new google.maps.InfoWindow({
									content: "<h1>"+params.title+"</h1>"+params.text
								});

								var map = $that.data('googleMap');

								google.maps.event.addListener(marker, 'click', function() {
								     infowindow.open(map, marker);
								});
							} else if(params.url) {
								google.maps.event.addListener(marker, 'click', function() {
								     document.location = params.url;
								});
							}

							if (!params.id) {
							    
								$that.data('googleMarker').push(marker);
							} else {
								$that.data('googleMarker')[params.id] = marker;
							}

							if($that.data('googleMarker').length == 1) {
								$that.data('googleMap').setCenter(results[0].geometry.location);
								$that.data('googleMap').setZoom($that.data('googleMap').getZoom());
							} else {
								$that.data('googleMap').fitBounds($that.data('googleBound'));
							}

							var coords = {};
							coords.lat = results[0].geometry.location.lat();
							coords.lon = results[0].geometry.location.lng();

							params.success(coords, $this);

						} else {
						  
							if($this.data('googleDebug'))
								console.error("jQuery googleMap : Unable to find the place asked for the marker ("+status+")");
						}
					});
				}($this);
			} else {
			   
				$this.data('googleBound').extend(new google.maps.LatLng(params.coords[0], params.coords[1]));

        			if(params.icon) {
					var marker = new google.maps.Marker({
						map: $this.data('googleMap'),
						position: new google.maps.LatLng(params.coords[0], params.coords[1]),
						title: params.title,
						icon: params.icon,
						draggable: params.draggable
					});
				} else {
					var marker = new google.maps.Marker({
						map: $this.data('googleMap'),
						position: new google.maps.LatLng(params.coords[0], params.coords[1]),
						title: params.title,
						draggable: params.draggable
					});
				}

        			if(params.title != "" && params.text != "" && !params.url) {
          				var infowindow = new google.maps.InfoWindow({
						content: "<h1>"+params.title+"</h1>"+params.text
					});

					var map = $this.data('googleMap');

					google.maps.event.addListener(marker, 'click', function () {
					 
		        			infowindow.open(map, marker);
	        			});
				} else if(params.url) {
				    google.maps.event.addListener(marker, 'click', function () {				       
              					document.location = params.url;
        				});
				}

        			if (params.draggable) {
        			google.maps.event.addListener(marker, 'click', function () {
        			    // alert(marker.position);
        			    });
					google.maps.event.addListener(marker, 'dragend', function() {
						var location = marker.getPosition();

						var coords = {};

						coords.lat = location.lat();
						coords.lon = location.lng();

						params.success(coords, $this);
					});
				}

				if(!params.id) {
       					$this.data('googleMarker').push(marker);
        			} else {
        				$this.data('googleMarker')[params.id] = marker;
        			}

				if($this.data('googleMarker').length == 1) {
					$this.data('googleMap').setCenter(new google.maps.LatLng(params.coords[0], params.coords[1]));
					$this.data('googleMap').setZoom($this.data('googleMap').getZoom());
				} else {
					$this.data('googleMap').fitBounds($this.data('googleBound'));
				}

				params.success({
					lat: params.coords[0],
					lon: params.coords[1]
				}, $this);
			}
		});

		return this;
	}

	$.fn.removeMarker = function(id) {
		this.each(function() {
			var $this = $(this);

    			if(!$this.data('googleMap')) {
    				if($this.data('googleDebug'))
      					console.log("jQuery googleMap : Unable to delete a marker where there is no map !");
      					
      				return false;
    			}

    			var $markers = $this.data('googleMarker');

    			if(typeof $markers[id] != 'undefined') {
    				$markers[id].setMap(null);
    				
      				if($this.data('googleDebug'))
      					console.log('jQuery googleMap : marker deleted');
      					
      				return true;
    			} else {
      				if($this.data('googleDebug'))
      					console.error("jQuery googleMap : Unable to delete a marker if it not exists !");
      		
      				return false;
    			}
		});
	}

	$.fn.addWay = function(params) {
		params = $.extend( {
			start : false,
			end : false,
			step: [],
			route : false,
			langage : 'english'
		}, params);

		var direction = new google.maps.DirectionsService({
			region: "fr"
		});

		var way = new google.maps.DirectionsRenderer({
			draggable: true,
			map: $(this).data('googleMap'),
			panel: document.getElementById(params.route),
			provideTripAlternatives: true,
			polylineOptions: {
			    strokeColor: globalcolor,
			    strokeOpacity: 3.0,
			    strokeWeight:5
			}
		});
		
		document.getElementById.innerHTML = "";

		var waypoints = [];

    		for(var i in params.step) {
    			var step;
      			if(typeof params.step[i] == "object") {
        			step = new google.maps.LatLng(params.step[i][0], params.step[i][1]);
      			} else {
        			step = params.step[i];
      			}

      			waypoints.push({
      				location: step,
      				stopover: true
      			});
		}

		if(typeof params.end != "object") {
			var geocodeAsync = function($that) {
				var geocoder = new google.maps.Geocoder();

		    		geocoder.geocode({
		    			address  : params.end,
		    			bounds   : $that.data('googleBound'),
		    			language : params.langage
		    		}, function(results, status) {
	        			if (status == google.maps.GeocoderStatus.OK) {
	        				var request = {
	            					origin: params.start,
	            					destination: results[0].geometry.location,
	            					travelMode: google.maps.DirectionsTravelMode.DRIVING,
	            					region: "fr",
	            					waypoints: waypoints
		        			};

		        			direction.route(request, function(response, status) {
	            					if (status == google.maps.DirectionsStatus.OK) {
	            					    way.setDirections(response);
	            					} else {
	              						if($that.data('googleDebug'))
	            							console.error("jQuery googleMap : Unable to find the place asked for the route ("+response+")");
	            					}
		        			});

	        			} else {
	          				if($that.data('googleDebug'))
	          					console.error("jQuery googleMap : Address not found");
	        			}
		    		});
	    		}($(this));
		} else {
			var request = {
				origin: params.start,
				destination: new google.maps.LatLng(params.end[0], params.end[1]),
				travelMode: google.maps.DirectionsTravelMode.DRIVING,
				region: "fr",
				waypoints: waypoints
			};

			direction.route(request, function(response, status) {
				if (status == google.maps.DirectionsStatus.OK) {
					way.setDirections(response);
				} else {
					if($(this).data('googleDebug'))
          					console.error("jQuery googleMap : Address not found");
				}
			});
		}

		return this;
	}

	

	//$.fn.addListenerClick = function () {	    	   
	//    this.each(function () {
	//    google.maps.event.addListener($this.data('googleMap'), 'click', function (e) {
	            
	//            var lat = e.latLng.lat();
	//            var lng = e.latLng.lng();
	//            var pp = false; var startpoint_lat=""; startpoint_ln="";
	//            var $markers = $this.data('googleMarker');
	//            for (var i = 0; i < $markers.length; i++) {
	//                if ($markers[i].id == 'startpoint') { pp = true;}
	//            }
	//            if (!pp) {
	                 
	//            var marker = new google.maps.Marker({
	//                map: $this.data('googleMap'),
	//                position: new google.maps.LatLng(lat, lng),
	//                title: "startpoint",
	//                draggable: true,
	//                id: "startpoint"
	//            });
	//            $markers.push(marker);
	//        } else {	           
	//            var marker = new google.maps.Marker({
	//                map: $this.data('googleMap'),
	//                position: new google.maps.LatLng(lat, lng),
	//                title: "endpoint",
	//                draggable: true,
	//                id: "endpoint"
	//            }); 
	//            $markers.push(marker);
	//            for (var i = 0; i < $markers.length; i++) {
	//                if ($markers[i].id == 'startpoint') {
	                   
	//                    startpoint_lat = $markers[i].position.lat(); startpoint_lng = $markers[i].position.lng();
	//                }
	//            }
	//            alert('begin add way  ');
	//            //this.addWay({
	//            //    start: "257 Elles Rd, Strathern, Invercargill 9812, New Zealand", // postal address for the start marker (obligatory)
	//            //    end: [-46.427804, 168.362833], // postal address or gps coordinates for the end marker (obligatory)
	//            //    route: 'way', // Block's ID for the route display (optional)
	//            //    langage: 'english' // language of the route detail (optional)
	//            //});
	             
	//            //var flightPlanCoordinates = [
    //            //    new google.maps.LatLng(startpoint_lat, startpoint_lng),
    //            //    new google.maps.LatLng( lat,  lng)]
	//            ////������  
	//            //var flightPath = new google.maps.Polyline({
	//            //    path: flightPlanCoordinates,
	//            //    strokeColor: "#FF0000",
	//            //    strokeOpacity: 1.0,
	//            //    strokeWeight: 2
	//            //});
	//            //������������ͼ  
	//            //flightPath.setMap($this.data('googleMap'));
	//            alert('Succeed to add way(startpint:' + startpoint_lat + " : " + startpoint_lng + " endpoint:" + lat + " : " + lng + ")");
	//        }
	         
	       
	         
	        
	//        //google.maps.event.addListener(marker, 'dragend', function () {
	//        //         var location = marker.getPosition();
	//        //         var coords = {};
	//        //         coords.lat = location.lat();
	//        //         coords.lon = location.lng();
	//        //         alert(coords.lat + ":" + coords.lon);
	//        //     });
	//        //google.maps.event.addListener(marker, 'click', function () {
	//        //    infowindow.open(map, marker.id);
	//        //});

	//        });
	//    });
	//}

	$.fn.CreateCleanPath = function (color) {
	    globalcolor = color;
	    var startpoint_lat = "", startpoint_lng = ""; START_POINT = ""; FINAL_lng = ""; FINAL_lat = ""; StepPoint = [];
	    var $markers = $this.data('googleMarker'); 
	    for (var i = 0; i < $markers.length; i++) {	       
	        if ($markers[i].title == "StartPoint") {
	            startpoint_lat = $markers[i].position.lat(); startpoint_lng = $markers[i].position.lng();
	            START_POINT = startpoint_lat + ',' + startpoint_lng;
	        }
	        if ($markers[i].title == "DestinationPoint") {
	            FINAL_lat = $markers[i].position.lat(); FINAL_lng = $markers[i].position.lng();
	        }
	        if ($markers[i].title == "StepPoint") {	            
	            
	            var coords = [$markers[i].position.lat(), $markers[i].position.lng()];
	            
	            StepPoint.push(coords); 
	        }
	    }
	    
	    
	    geocodeLatLng(START_POINT);//gain postal address, the process is asynchronous,so we use setTimeout function to wait result 
	    var that = this;
	    setTimeout(function () {
 
	        that.addWay({
	            start: globalinfo, // postal address for the start marker (obligatory)
	            end: [FINAL_lat, FINAL_lng], // postal address or gps coordinates for the end marker (obligatory)
	            route: 'way', // Block's ID for the route display (optional)
	            langage: 'english', // language of the route detail (optional)
	            step: StepPoint
	        });
	    }, 1000);
	    
	   
	    //return this;
	}
	 

	function geocodeLatLng(position) {
	    var input = position;
	    var latlngStr = input.split(',', 2);
	    var latlng = { lat: parseFloat(latlngStr[0]), lng: parseFloat(latlngStr[1]) };
	    var geocoder = new google.maps.Geocoder;
	    var infocontent = "";
	           geocoder.geocode({ 'location': latlng }, function (results, status)
                                                        {                   
	                                                        if (status === google.maps.GeocoderStatus.OK)
	                                                        {
	                                                            if (results[1])
	                                                            {
	                                                                infocontent = results[0].formatted_address;
	                                                                initContinued(infocontent);
	                                                            } else { infocontent= 'No results found' ;}
	                                                        } else { infocontent = 'Geocoder failed due to: ' + status; }
	                 
                                                         } 
              
               );
	}
	function initContinued(addr) {
	    globalinfo = addr;
	}
	 

});
